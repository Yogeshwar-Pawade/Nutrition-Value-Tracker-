/** Collection of autocomplete search suggestions
 @namespace  nt.Collections
 @class nt.Collections.AutocompleteSearch
 @memberof! 
 @extends Backbone.Collection */
nt.Collections.AutocompleteSearch = Backbone.Collection.extend(/** @lends nt.Collections.AutocompleteSearch# */{

    model: nt.Models.Autocomplete,

    url: 'https://api.nutritionix.com/v2/autocomplete',

    api: {
        q: '',
        appId: '53242d79',
        appKey: '82289438a16ec7b92cdcf5ad054159c4'
    },

    apiError: function(collection, response) {
        var errMsg = response.status + ' ' + response.statusText + ' : ' +
                     'Autocomplete server request error. <br> ' +
                     'Please try again.';
        if(window.console) console.log(errMsg);
        $('#search-suggest .dropdown-menu')
            .show()
            .html('<li class="typeahead-error"><a>' + errMsg + '</a></li>');

    }, 

    fetch: function() {
        this.trigger( 'fetch', this );
        return Backbone.Model.prototype.fetch.apply( this, arguments );

    } 

});
