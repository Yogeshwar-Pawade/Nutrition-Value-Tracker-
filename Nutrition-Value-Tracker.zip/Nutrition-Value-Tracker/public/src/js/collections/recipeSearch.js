/** Collection of recipes
 @namespace  nt.Collections
 @class nt.Collections.RecipeSearch
 @memberof! <global>
@extends Backbone.Collection */
nt.Collections.RecipeSearch = Backbone.Collection.extend(/** @lends nt.Collections.RecipeSearch# */{

    model: nt.Models.Recipe,

    url: 'https://api.edamam.com/search',

    sync: function(method, collection, options) {
        options.dataType = 'jsonp'; // cross origin workaround
        return Backbone.sync(method, collection, options);
    },

    parse: function(response) {
        return response.hits;
    } 

});
