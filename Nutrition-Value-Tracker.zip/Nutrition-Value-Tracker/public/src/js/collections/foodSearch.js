/** Collection of foods searched
 @namespace  nt.Collections
 @class nt.Collections.FoodSearch
 @memberof! <global>
 @extends Backbone.Collection */
nt.Collections.FoodSearch = Backbone.Collection.extend(/** @lends nt.Collections.FoodSearch# */{

    model: nt.Models.Food,

    searchPhrase: '',

    url: function() {
        return 'https://api.nutritionix.com/v1_1/search/' + this.searchPhrase;
    }, 

    parse: function(response) {
        return response.hits;
    }, 

    /** This generates the next order number for new items.
    * @returns {number} Next order number */
    nextOrder: function() {
        if ( !this.length ) {
            return 1;
        }
            return this.last().get('sortOrder') + 1;

    },

    /**  Each food item is sorted by its original insertion order.
    * @returns {number} Sort order */
    comparator: function( food ) {
            return food.get('sortOrder');
    } 

});
