/** Nutrition View
 @namespace  nt.Views
 @class nt.Views.Nutrition
 @memberof! <global>
 @extends Backbone.View */
nt.Views.Nutrition = Backbone.View.extend(
  /** @lends nt.Views.Nutrition# */ {
    el: "#app",

    buttonsTemplate: Handlebars.Templates.buttons,

    events: {
      "click .item-nutrition": "openNutrition",
      "click #nutrition-close": "closeNutrition",
      "click #nutrition-add": "addFood",
      "click #nutrition-remove": "removeFood",
      "click #nutrition-track": "openTrackerView",
    },

    initialize: function () {
      _.bindAll(this, "itemSuccess", "itemError");

      this.$nutrition = $("#nutrition");
      this.$nutritionTop = $("#nutrition-top");
      this.$nutritionMenu = $("#nutrition-button-menu");
      this.$nutritionResults = $("#nutrition-results");
      this.$nLabel = $("#nlabel");
      this.trackedItem = null;
      this.gchart = null;
      this.gformat = null;

      google.charts.load("current", { packages: ["corechart"] });

      this.listenTo(nt.Plugin.Instance, "selected", this.closeNutrition);

      this.listenTo(this.model, "foodsaved", this.updateView);
    },

    render: function () {
      this.displayMenu();

      this.displayChart();

      this.displayNutrition();
    },

    showColumn: function () {
      this.$nutrition.removeClass("hideColumn");
    },

    hideColumn: function () {
      this.$nutrition.addClass("hideColumn");
    },

    openNutrition: function (e) {
      var elem = $(e.target);
      var id = elem.data("item");

      e.preventDefault();

      this.closeNutrition();

      elem
        .closest(".item")
        .css("background-color", "#b8dec0")
        .addClass("highlight");

      this.showColumn();

      this.checkItem(id);
    },

    checkItem: function (itemId) {
      this.trackedItem = nt.Collections.tracker.get(itemId);

      if (this.trackedItem) {
        this.model.set(this.trackedItem.toJSON());

        this.itemSuccess();
      } else {
        this.getNutrition(itemId);
      }
    },

    closeNutrition: function () {
      $(".highlight").removeAttr("style").removeClass("highlight");

      this.$nutritionResults.find("figure").html("");

      this.hideColumn();

      $(".tracked-delete").show();
    },

    itemSuccess: function (model, response) {
      this.render();

      $(".row").eqHeights({ child: ".eqHeights" });
    },

    itemError: function (model, errorResponse) {
      var status = errorResponse.status;
      var statusText = errorResponse.statusText;
      var msg =
        '<div class="alert alert-danger">Nutritionix item request failed: <br>' +
        status +
        " : " +
        statusText +
        "</div>";
      this.$nutritionMenu.html(msg);
    },

    getNutrition: function (itemID) {
      var parameters = {
        id: itemID,
        appId: "53242d79",
        appKey: "82289438a16ec7b92cdcf5ad054159c4",
      };

      this.$nutritionMenu.html(nt.preloader);

      this.model.clear();

      this.model.fetch({
        data: $.param(parameters),
        success: this.itemSuccess,
        error: this.itemError,
      });
    },

    displayChart: function () {
      var fat = this.model.get("valueTotalFat");
      var carbs = this.model.get("valueTotalCarb");
      var protein = this.model.get("valueProteins");

      var data = google.visualization.arrayToDataTable([
        ["Nutrient", "Value"],
        ["Fat", fat],
        ["Carbs", carbs],
        ["Protein", protein],
      ]);

      var options = {
        width: 280,
        height: 140,
        backgroundColor: "#b8dec0",
        sliceVisibilityThreshold: 0,
      };

      var notZero = parseFloat(fat + carbs + protein) !== 0;

      if (notZero) {
        if (!this.gformat)
          this.gformat = new google.visualization.NumberFormat({ suffix: "g" });

        if (this.gchart) this.gchart.clearChart();

        this.gchart = new google.visualization.PieChart(
          document.getElementById("gchart")
        );

        this.gformat.format(data, 1);

        this.gchart.draw(data, options);
      }
    },

    displayNutrition: function () {
      this.$nLabel.html("");
      this.$nLabel.undelegate();

      this.$nLabel.nutritionLabel(this.model.toJSON());
    },

    displayMenu: function () {
      var isTracked = false;

      this.$nutritionMenu.html("");

      if (this.trackedItem) isTracked = true;

      this.$nutritionMenu.append(
        this.buttonsTemplate({
          tracking: isTracked,
        })
      );
    },

    addFood: function () {
      var editorView = new nt.Views.Editor({ model: this.model });

      this.$nutrition.append(editorView.render().renderDatePicker().el);
    },

    removeFood: function () {
      var id = this.model.get("id");
      var food = nt.Collections.tracker.get(id);
      food.destroy();
      this.trackedItem = null;
      this.displayMenu();
    },

    updateView: function () {
      var itemId = this.model.get("id");
      var foodAttributes = nt.Collections.tracker.get(itemId).toJSON();
      this.model.set(foodAttributes);
      this.displayNutrition();
      this.trackedItem = true;
      this.displayMenu();
    },

    openTrackerView: function () {
      this.closeNutrition();
      $("#tab2").trigger("click");
    },
  }
);
