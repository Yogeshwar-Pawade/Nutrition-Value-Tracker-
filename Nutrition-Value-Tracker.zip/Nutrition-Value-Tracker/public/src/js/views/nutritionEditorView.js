/** Tracker Editor View
@namespace  nt.Views
@class nt.Views.Editor
@memberof! <global>
@extends Backbone.View */
nt.Views.Editor = Backbone.View.extend(
  /** @lends nt.Views.Editor# */ {
    tagName: "div",

    className: "edit-item",

    editorTemplate: Handlebars.Templates.editor,

    count: 1,

    events: {
      "click #foodSave": "saveFood",
      "click #foodClose": "close",
      "click #servingIncrease": "servingIncrease",
      "click #servingDecrease": "servingDecrease",
    },

    initialize: function () {
      this.createFood().listenTo(this.food, "change", this.updateView);
    },

    updateView: function () {
      var prev = $("#dateTimePicker").data("DateTimePicker").date();
      $("#dateTimePicker").data("DateTimePicker").destroy();
      this.render().renderDatePicker();

      if (prev)
        this.$el.find("#dateTimePicker").data("DateTimePicker").date(prev);
    },

    render: function () {
      this.$el.html(this.editorTemplate(this.food.toJSON()));
      return this;
    },

    renderDatePicker: function () {
      this.$el.find("#dateTimePicker").datetimepicker({
        format: "YYYY-MM-DD",
        allowInputToggle: true,
        widgetPositioning: { horizontal: "right" },
      });

      return this;
    },

    renderError: function (message) {
      var error =
        '<p class="bs-callout bs-callout-danger alert-danger"><i class="glyphicon glyphicon-exclamation-sign"></i> ' +
        message +
        "</p>";
      this.$el.find("#editor-top").append(error);
    },

    removeError: function () {
      this.$el.find(".bs-callout").remove();
    },

    getFoodAttributes: function () {
      return this.model.toJSON();
    },

    userAttributes: function () {
      return {
        trackDate: this.$el.find("#foodTrackDate").val().trim(),
        itemName: this.$el.find("#foodName").val().trim(),
        servingCount: this.count,
        moreThanOne: this.count > 1,
      };
    },

    createFood: function () {
      var attrs = this.getFoodAttributes();

      this.food = new nt.Models.Nutrition();

      this.food.set(attrs);

      var servings = this.food.get("servingCount");

      if (servings > 1) {
        this.count = servings;
        this.food.valueUpdate(attrs, servings);
      }

      return this;
    },

    saveFood: function (e) {
      e.preventDefault();

      this.removeError();

      if (this.count > 1) this.food.valueUpdate(this.getFoodAttributes(), 1);

      var userAttr = this.userAttributes();

      this.food.set(userAttr, { validate: true });

      var notValid = this.food.validationError;

      if (notValid) {
        this.renderError(notValid);
      } else {
        nt.Collections.tracker.create(this.food, { merge: true });

        this.model.trigger("foodsaved");

        this.close();
      }
    },

    close: function () {
      $("#dateTimePicker").data("DateTimePicker").destroy();
      this.remove();
    },

    servingIncrease: function () {
      if (this.count >= 1) this.count++;

      this.food.valueUpdate(this.getFoodAttributes(), this.count);
    },

    servingDecrease: function () {
      if (this.count >= 2) this.count--;

      this.food.valueUpdate(this.getFoodAttributes(), this.count);
    },
  }
);
